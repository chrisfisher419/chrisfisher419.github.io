﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
using static System.Convert;


namespace MyFirstIf
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("You: Welcome to Budget Mart! We have a wide variety of available items!: Apples, Avocados, Bananas, Cherries, and Grapes ");
            ReadLine();



            WriteLine("Customer: Hello, my name is Johnathan Davis, I would like to know the price of your items, to start with how much are the apples?");
            ReadLine();

            double apples = 0;
            WriteLine("You: I'm glad you asked, the price of the apples is [ENTER PRICE]: ");

            apples = ToDouble(ReadLine());

            if (apples < 2)
            {
                WriteLine("Customer ${0}? isn't bad, how much are the Avocados?", apples);
            }
            else
            {
                WriteLine("Customer: Wow that is way too much man, but alright, how much are the Avocados?");
            }
            ReadLine();

            double avocados = 0;
            WriteLine("You: The best prices in town, they are: [ENTER PRICE]");
            avocados = ToDouble(ReadLine());

            if (avocados < 2)
            {
                WriteLine("Customer: ${0}? That's Fantastic! Mind telling me how much the Bananas are?", avocados);
            }
            else
            {
                WriteLine("Customer: Dude are you trying to make me broke, this is insane, but whatever, tell me about those bananas");
            }
            ReadLine();

            double bananas = 0;
            WriteLine("You: Oh yeah, they are: [ENTER PRICE]");
            bananas = ToDouble(ReadLine());

            if (bananas < 2)
            {
                WriteLine("Customer: Wow! ${0} is so cheap! I need to know the prices of your cherries!", bananas);
            }
            else
            {
                WriteLine("Customer: I'm losing my patience with these prices, I work at McDonalds, not Microsoft... tell me the cherries are better...");
            }
            ReadLine();

            double cherries = 0;
            WriteLine("You: We have the best cherries available for the best price of: [ENTER PRICE]");
            cherries = ToDouble(ReadLine());

            if (cherries < 2)
            {
                WriteLine("Customer: ${0}? You have got me sold! Last, the price your grapes?", cherries);
            }
            else
            {
                WriteLine("Customer: I'm about to leave man, my wallet is nearly empty....those grapes have to be cheap though...please...");
            }
            ReadLine();

            double grapes = 0;
            WriteLine("You: A mere price of: [ENTER PRICE]");
            grapes = ToDouble(ReadLine());

            if (grapes < 2)
            {
                WriteLine("Customer: Awesome!, and what is my final total?");
            }
            else
            {
                WriteLine("That, again, is way too much, this is highway robbery... what is my total?");
            }
            ReadLine();

            double result = (apples + avocados + bananas + cherries + grapes);
            WriteLine("You: Well before taxes we have: ${0}", result);
            ReadLine();

            double tax = (result * .06);
            double final = (result + tax);
            WriteLine("You: Our tax here is 6%, so the total tax will be: ${0}", tax);
            WriteLine($"Thus our total is {String.Format("{0:C}", final)}");
            ReadLine();

            if (final < 20)
            {
                WriteLine("Customer: Wow! I have never spent so little for so much! Thank you, this will be my go to store from now on!");
            }
            else
            {
                WriteLine("Customer: This is worse than my student loans... I really hope this store goes out of business in the near future...bye");
            }
            ReadLine();


        }
    }
}
